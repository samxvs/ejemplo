package WmPF_Common;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2007-03-20 09:56:08 EDT
// -----( ON-HOST: 172.22.25.11

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void getListIndex (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getListIndex)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required listInterest
		// [i] field:0:required index
		// [o] field:0:required stringValue
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	listInterest = IDataUtil.getStringArray( pipelineCursor, "listInterest" );
			String index = IDataUtil.getString( pipelineCursor, "index" );
		pipelineCursor.destroy();
		
			int idx = new Integer(index).intValue();
			String stringValue = listInterest[idx];
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "stringValue", stringValue );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void randomizer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(randomizer)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required factorOfTen
		// [o] field:0:required randomNum
		double theNum = Math.random();
		
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	factor = IDataUtil.getString( pipelineCursor, "factorOfTen" );
		pipelineCursor.destroy();
		
			if (factor == "") {
				factor = "1";
			}
		
			int theF = new Integer(factor).intValue();
			
			long ms = Math.round(Math.random()*theF);
			
			
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "randomNum", new Long(ms).toString());
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void rangeRandomizer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(rangeRandomizer)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required startRange
		// [i] field:0:required endRange
		// [o] field:0:required value
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	startRange = IDataUtil.getString( pipelineCursor, "startRange" );
			String	endRange = IDataUtil.getString( pipelineCursor, "endRange" );
		pipelineCursor.destroy();
			int baseFactor = 0;
			int vLen = (new Integer(endRange).intValue() - new Integer(startRange).intValue()) + 1;
		
			
			int sample1 = -1;
			int sample2 = -1;
			int size = 0;
			double num = 0;
			int ranSize = 0;
			int endint = new Integer(endRange).intValue();
			int startint = new Integer(startRange).intValue();
			int value = 0;
			String sample1Str = "";
			String sample2Str = "";
		
			while (((sample1 > endint) | (sample1==0 && startint != 0) | (sample1 < startint)) && ((sample2 > endint) | (sample2==0 && startint != 0)  |  (sample2 < startint))) {
				num = Math.random();
				size = endRange.length();
				ranSize = new Double(num).toString().length();
				sample1Str = new String(new Double(num).toString()).substring(3, size+3);
				sample2Str = new String(new Double(num).toString()).substring(ranSize-size, ranSize);
				int vLoc = sample1Str.indexOf("E");
				int vLoc2 = sample2Str.indexOf("E");
		
						
				if (vLoc == -1 && vLoc2 == -1) {
					sample1 = new Integer(sample1Str).intValue();
					sample2 = new Integer(sample2Str).intValue();
		
				}
		
			}
		
		
			if ((sample1 <= endint) && (sample1 >= startint)) {
				value = sample1;
			}
			else  {
				value = sample2;
			}
		
		
		
		
			
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", new Integer(value).toString());
		pipelineCursor_1.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void timeDelay (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(timeDelay)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required msToDelay
		long ms = 0;
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	msToDelay = IDataUtil.getString( pipelineCursor, "msToDelay" );
		pipelineCursor.destroy();
		
			ms = new Long(msToDelay).longValue();
			try {
				Thread.sleep(ms);
			} catch (Exception ex) {System.out.println(ex);}
		
		// pipeline
		// --- <<IS-END>> ---

                
	}
}

