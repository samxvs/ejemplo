if (!window.WebSocket && window.MozWebSocket) {
    window.WebSocket = window.MozWebSocket;
}

if (!window.WebSocket) {
    alert("WebSocket not supported by this browser");
}

function $() {
    return document.getElementById(arguments[0]);
}
function $F() {
    return document.getElementById(arguments[0]).value;
}

function getKeyCode(ev) {
    if (window.event)
        return window.event.keyCode;
    return ev.keyCode;
}

var wstool = {
    connect : function() {
		var accessToken = document.getElementById("accessToken").value;
        var location = document.getElementById("wsURI").value;
		location = location + "?user="+document.getElementById("user").value;
		if (accessToken && accessToken != '') {
			location = location + "&x-Gateway-APIKey="+accessToken;
		}
        //var location = 'ws://mcmalli01:7070/context/';

        wstool.info("Document URI: " + document.location);
        wstool.info("WS URI: " + location);
        
        this._scount = 0;
        
        var options = {
                'host': 'mcmalli01',
                'port': 8082,
                'method': 'GET',
                'headers':{
                            "Authorization":"Basic YTph",
                            "a" : "a"
                        }
            
            };
        try {
            this._ws = new WebSocket(location);
            this._ws.onopen = this._onopen;
            this._ws.onmessage = this._onmessage;
            this._ws.onclose = this._onclose;
        } catch (exception) {
            wstool.info("Connect Error: " + exception);
        }
    },

    close : function() {
        this._ws.close(1000);
    },
    
    _out : function(css, message) {
        var console = $('console');
        var spanText = document.createElement('span');
        spanText.className = 'text ' + css;
        spanText.innerHTML = message;
        var lineBreak = document.createElement('br');
        console.appendChild(spanText);
        console.appendChild(lineBreak);
        console.scrollTop = console.scrollHeight - console.clientHeight;
    },

    setState : function(enabled) {
        $('connect').disabled = enabled;
        $('close').disabled = !enabled;
        $('hello').disabled = !enabled;
    },
    
    info : function(message) {
        wstool._out("info", message);
    },

    error : function(message) {
        wstool._out("error", message);
    },

    infoc : function(message) {
        wstool._out("client", "[c] " + message);
    },
    
    infos : function(message) {
        this._scount++;
        wstool._out("server", "[s" + this._scount + "] " + message);
    },
    
    _onopen : function() {
        wstool.setState(true);
        wstool.info("Websocket Connected");
    },

    _send : function(message) {
        if (this._ws) {
            this._ws.send(message);
            wstool.infoc(message);
        }
    },

    write : function(text) {
        wstool._send(text);
    },

    _onmessage : function(m) {
        if (m.data && m.data.indexOf("Server Time") < 0) {
            wstool.infos(m.data);
        } else if (m.data) {
			document.getElementById("serverTime").innerHTML = m.data;
		}
		
    },

    _onclose : function(closeEvent) {
        this._ws = null;
        wstool.setState(false);
        wstool.info("Websocket Closed");
        wstool.info("  .reason = " + JSON.stringify(closeEvent));
    }
};
