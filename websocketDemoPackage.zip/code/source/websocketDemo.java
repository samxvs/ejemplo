

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.websocket.demo.WebSocketAPI;
// --- <<IS-END-IMPORTS>> ---

public final class websocketDemo

{
	// ---( internal utility methods )---

	final static websocketDemo _instance = new websocketDemo();

	static websocketDemo _newInstance() { return new websocketDemo(); }

	static websocketDemo _cast(Object o) { return (websocketDemo)o; }

	// ---( server methods )---




	public static final void deployAPI (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deployAPI)>> ---
		// @sigtype java 3.5
		IDataCursor cursor = pipeline.getCursor();
		String relativeURI = IDataUtil.getString(cursor, "relativeURI");
		if (relativeURI == null || relativeURI.isEmpty()) {
			relativeURI = "/ws/demo";
		}
		WebSocketAPI.deploy(relativeURI);
		// --- <<IS-END>> ---

                
	}



	public static final void shoutdown (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(shoutdown)>> ---
		// @sigtype java 3.5
		WebSocketAPI.undeploy("/api/demo/");
		// --- <<IS-END>> ---

                
	}



	public static final void startup (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(startup)>> ---
		// @sigtype java 3.5
		WebSocketAPI.deploy("/api/demo/");
			
		// --- <<IS-END>> ---

                
	}



	public static final void undeployAPI (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(undeployAPI)>> ---
		// @sigtype java 3.5
		IDataCursor cursor = pipeline.getCursor();
		String relativeURI = IDataUtil.getString(cursor, "relativeURI");
		if (relativeURI == null || relativeURI.isEmpty()) {
			relativeURI = "/ws/demo";
		}
		WebSocketAPI.undeploy(relativeURI);
		// --- <<IS-END>> ---

                
	}
}

